cd ~/downloads
mkdir FloDynamicTAB-1.2.8-test
cd FloDynamicTAB-1.2.8-test
cp ../FloDynamicTAB-1.2.8.jar ./
cp ../FloDynamicTAB-1.2.8-external-github-configs.zip ./
unzip FloDynamicTAB-1.2.8-external-github-configs.zip
ls
