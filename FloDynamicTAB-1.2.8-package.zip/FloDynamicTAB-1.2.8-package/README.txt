FloDynamicTAB 1.2.8 external GitHub fix

Why 1.2.8 exists:
The latest log showed the pack was sent and accepted, then immediately FAILED_DOWNLOAD.
The plugin sent the SHA1 of the locally generated server pack:
36ad727192e499640021f562abf6567ae242af5e

But the uploaded GitHub zip we gave you has this SHA1:
4c3f545e584c5c3f08feae14948401774eafd63b

Minecraft verifies the hash. If the URL file hash and sent SHA1 do not match, the client rejects/fails the download.

1.2.8 adds:
resource-pack-external-sha1: "4c3f545e584c5c3f08feae14948401774eafd63b"

Use:
- FloDynamicTAB-1.2.8.jar on Lobby and router
- paper/FloDynamicTAB-config-external-github.yml on Lobby
- router/FloDynamicTAB-config.yml on router

Direct pack URL configured:
https://raw.githubusercontent.com/Gregorilass/DynamicTab/main/FloDynamicTAB-core-pack-1.2.7.zip

After restart/join, run:
/fdt packcheck
/fdt testglyph chat

Expected:
- SHA1 sent to client should show 4c3f545e584c5c3f08feae14948401774eafd63b (external override)
- Last client status should become SUCCESSFULLY_LOADED
- glyph test should show icons instead of squares

If it still says FAILED_DOWNLOAD after this, the GitHub raw URL is probably not serving the exact file from root/main or the repo/file is private/not reachable by Minecraft.
