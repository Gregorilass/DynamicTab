# Termux compile commands

Use a new folder in Downloads:

```bash
cd ~/downloads
```

```bash
mkdir FloDynamicTAB-1.2.7-build
```

```bash
cd FloDynamicTAB-1.2.7-build
```

```bash
unzip ../FloDynamicTAB-1.2.7-source.zip
```

```bash
cd FloDynamicTAB-1.2.7-work
```

```bash
chmod +x build.sh
```

```bash
./build.sh
```

Compiled jar will be here:

```text
FloDynamicTAB-1.2.7-work/target/FloDynamicTAB-1.2.7.jar
```
