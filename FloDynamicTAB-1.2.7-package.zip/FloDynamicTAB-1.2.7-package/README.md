# FloDynamicTAB 1.2.7

This update changes FloDynamicTAB so the resource pack can be hosted externally/cloud/static instead of requiring open HTTP ports on the server PC.

## Main changes

- Adds `resource-pack-mode: "external"`.
- Adds `resource-pack-auto-host-enabled: false` to disable the internal 8125 web server.
- Keeps local pack generation so the server can still build the zip from `logo/` and `server-icons/`.
- Adds `/fdt exportpack` to rebuild the pack and show the exact file to upload.
- Keeps `/fdt packcheck`, `/fdt glyphmap`, `/fdt testglyph chat/title/tab/all`.
- Supports URL placeholders: `{hash}`, `{sha1}`, and `{file}` in `resource-pack-public-url`.

## Upload file

Upload this file to a host that gives a direct public `.zip` download URL:

`FloDynamicTAB-core-pack-1.2.7.zip`

The included uploadable pack contains:

- `<logo>` -> `U+E000` -> `flocraft_logo.png`
- `<lobby_icon>` -> `U+E041` -> `flodynamic_lobby.png`
- `<survival_icon>` -> `U+E042` -> `flodynamic_survival.png`
- `<elite_icon>` -> `U+E043` -> `flodynamic_elite.png`
- `<chunkchallenge_icon>` -> `U+E044` -> `flodynamic_chunkchallenge.png`
- `<rpg_icon>` -> `U+E045` -> `flodynamic_rpg.png`
- `<oneblock_icon>` -> `U+E046` -> `flodynamic_oneblock.png`
- `<skyblock_icon>` -> `U+E047` -> `flodynamic_skyblock.png`
- `<creative_icon>` -> `U+E048` -> `flodynamic_creative.png`

## Lobby config for external hosted pack

After uploading the zip, set Lobby `plugins/FloDynamicTAB/config.yml` to use the direct URL:

```yml
resource-pack-auto-enabled: true
resource-pack-mode: "external"
resource-pack-auto-host-enabled: false
resource-pack-send-on-join: true
resource-pack-force: false
resource-pack-public-url: "PASTE_DIRECT_ZIP_URL_HERE"
resource-pack-generated-name: "FloDynamicTAB-core-pack-1.2.7.zip"
resource-pack-cache-bust-url: false
resource-pack-cache-bust-mode: "off"
resource-pack-rebuild-on-startup: true
resource-pack-merge-current-server-pack: false
```

For servers with an existing pack such as Elite/Nexo, use a merged pack URL later instead of this core-only pack.

## Test commands

```text
/fdt packurl
/fdt packcheck
/fdt glyphmap
/fdt testglyph chat
```

If `/fdt testglyph chat` shows icons after the external URL is used, the cloud/static hosting works.
